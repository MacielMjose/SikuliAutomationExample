# SikuliAutomation
Automação de Testes utilizando Java +Framework Sikuli
