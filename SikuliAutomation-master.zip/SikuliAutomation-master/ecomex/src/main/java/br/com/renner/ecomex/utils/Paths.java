package br.com.renner.ecomex.utils;

public class Paths {
	
	public static final String createPricePath = "\\src\\main\\resources\\images\\changePrice\\";

}
